# WebAudit OSS

WebAudit OSS is a free and open-source website auditing tool for **SEO, accessibility, mobile readiness, social metadata, security basics and basic performance checks**.

Enter a website URL, run the audit, and WebAudit gives you a score plus individual **Passed / Warning / Issue** results explaining what was found.

## Features

- URL-based website audits with a simple 0-100 score
- SEO checks: title, meta description, H1, canonical and robots metadata
- Accessibility checks: image alt attributes, document language and link naming heuristics
- Mobile viewport check
- HTTPS check
- Open Graph/social metadata check
- HTML size and response-time indicators
- SSRF protection against common local/private network targets
- No account required
- No database required
- No API key required

## Requirements

Before starting, install:

- **Node.js 18 or newer**
- npm (included with Node.js)

Check that Node.js is installed:

```bash
node --version
npm --version
```

If `node` is not recognized, install Node.js and then reopen your terminal.

## Installation and startup

### Windows

1. Download this repository as a ZIP or clone it with Git.
2. Extract the ZIP.
3. Open the extracted `webaudit-oss` folder.
4. Click the address bar in File Explorer, type `cmd`, and press Enter.
5. Install the dependencies:

```bash
npm install
```

6. Start WebAudit:

```bash
npm start
```

7. When the terminal says the server is running, open your browser and go to:

```text
http://localhost:3000
```

Keep the terminal window open while using WebAudit.

To stop the server, return to the terminal and press `Ctrl + C`.

### macOS / Linux

Open Terminal in the project folder and run:

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

Stop the server with `Ctrl + C`.

## Quick start

If Node.js is already installed, the whole setup is simply:

```bash
npm install
npm start
```

Then visit `http://localhost:3000`.

## How to use WebAudit

1. Start the application.
2. Open `http://localhost:3000`.
3. Enter a public website, for example `example.com` or `https://example.com`.
4. Start the audit.
5. Review the overall score and each individual check.

WebAudit only performs lightweight checks and does not modify the website being audited.

## Project structure

```text
webaudit-oss/
├── public/
│   ├── index.html      # User interface
│   ├── app.js          # Frontend logic
│   └── style.css       # Interface styling
├── src/
│   ├── audit.js        # Website audit engine
│   └── server.js       # Express server and API
├── .github/
│   └── workflows/      # GitHub Actions
├── CONTRIBUTING.md
├── LICENSE
├── package.json
└── README.md
```

## Troubleshooting

### `node` or `npm` is not recognized

Node.js is either not installed or your terminal has not picked up the installation yet. Install Node.js 18+ and reopen Command Prompt/Terminal.

### Port 3000 is already in use

Another application may already be using port 3000. Stop that application before starting WebAudit again.

### The audit cannot reach a website

Make sure the website is publicly accessible and that your internet connection is working. WebAudit intentionally blocks common localhost and private-network targets as a security measure.

### I changed the code but nothing changed

Restart the server with `Ctrl + C` followed by:

```bash
npm start
```

Then refresh the browser page.

## Development

Install dependencies:

```bash
npm install
```

Run the application:

```bash
npm start
```

The frontend is in `public/` and the audit/server code is in `src/`.

When adding a new audit rule, keep the result understandable: explain what was checked, why it matters, and avoid presenting heuristics as absolute facts.

## Roadmap

- robots.txt and sitemap.xml checks
- Safe broken-link crawler
- Structured data inspection
- Exportable JSON and HTML reports
- Automated tests
- Optional Lighthouse integration
- Localization
- More detailed accessibility checks

## Contributing

Contributions are welcome. You can open an issue for a bug or feature idea, or submit a pull request.

See [CONTRIBUTING.md](CONTRIBUTING.md) for contribution guidelines.

## Security

WebAudit fetches user-supplied URLs, so URL handling is treated as a security-sensitive feature. The server rejects common private/local network targets.

If you discover a security bypass or vulnerability, please avoid publishing exploitation details before the maintainer has had a chance to investigate and fix the issue.

## Disclaimer

WebAudit provides automated indicators and heuristics. A passing result does not guarantee complete SEO, accessibility, security or performance compliance. For important production systems, combine automated checks with appropriate manual testing and specialist tools.

## License

WebAudit OSS is released under the **MIT License**. See [LICENSE](LICENSE).

import express from 'express'; import path from 'node:path'; import { fileURLToPath } from 'node:url'; import { auditWebsite } from './audit.js';
const app=express(); const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:'20kb'})); app.use(express.static(path.join(__dirname,'../public')));
app.post('/api/audit', async(req,res)=>{ try { res.json(await auditWebsite(req.body?.url)); } catch(e){ res.status(400).json({error:e.message||'Audit failed.'}); } });
const port=process.env.PORT||3000; app.listen(port,()=>console.log(`WebAudit OSS → http://localhost:${port}`));

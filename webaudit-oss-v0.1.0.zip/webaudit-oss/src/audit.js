import * as cheerio from 'cheerio';
import dns from 'node:dns/promises';
import net from 'node:net';

function result(id, title, status, detail, category, points = 1) { return { id, title, status, detail, category, points }; }
function normalizeUrl(input) { const raw = String(input || '').trim(); if (!raw) throw new Error('Enter a URL.'); return new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`); }

async function assertPublicHost(url) {
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  const host = url.hostname.toLowerCase();
  if (host === 'localhost' || host.endsWith('.local')) throw new Error('Local addresses are not allowed.');
  const records = await dns.lookup(host, { all: true });
  const privateIp = ip => net.isIP(ip) && (/^10\./.test(ip) || /^127\./.test(ip) || /^192\.168\./.test(ip) || /^169\.254\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip) || ip === '::1' || /^fc/i.test(ip) || /^fd/i.test(ip) || /^fe80:/i.test(ip));
  if (!records.length || records.some(r => privateIp(r.address))) throw new Error('Private or local network addresses are not allowed.');
}

export async function auditWebsite(input) {
  const url = normalizeUrl(input); await assertPublicHost(url);
  const started = Date.now();
  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 12000);
  let response;
  try { response = await fetch(url, { signal: controller.signal, redirect: 'follow', headers: { 'user-agent': 'WebAudit-OSS/0.1 (+open-source website audit)' } }); }
  catch { throw new Error('Could not load that website. Check the address and try again.'); }
  finally { clearTimeout(timer); }
  if (!response.ok) throw new Error(`Website returned HTTP ${response.status}.`);
  const type = response.headers.get('content-type') || '';
  if (!type.includes('text/html')) throw new Error('The URL did not return an HTML page.');
  const html = await response.text(); const elapsed = Date.now() - started; const $ = cheerio.load(html);
  const title = $('title').first().text().trim(); const desc = $('meta[name="description"]').attr('content')?.trim() || '';
  const h1s = $('h1'); const imgs = $('img'); const missingAlt = $('img').filter((_, e) => !$(e).attr('alt')).length;
  const links = $('a[href]'); const emptyLinks = links.filter((_, e) => !($(e).text().trim() || $(e).attr('aria-label') || $(e).find('img[alt]').length)).length;
  const viewport = $('meta[name="viewport"]').attr('content'); const lang = $('html').attr('lang'); const canonical = $('link[rel="canonical"]').attr('href');
  const robots = $('meta[name="robots"]').attr('content'); const ogTitle = $('meta[property="og:title"]').attr('content');
  const checks = [
    result('https','HTTPS',url.protocol === 'https:'?'pass':'warn',url.protocol === 'https:'?'Page uses HTTPS.':'Page is not using HTTPS.','Security',2),
    result('title','Page title',title.length>=10&&title.length<=60?'pass':title?'warn':'fail',title?`${title.length} characters: ${title}`:'Missing <title>.','SEO',2),
    result('description','Meta description',desc.length>=70&&desc.length<=170?'pass':desc?'warn':'fail',desc?`${desc.length} characters.`:'Missing meta description.','SEO',2),
    result('h1','H1 heading',h1s.length===1?'pass':h1s.length?'warn':'fail',`${h1s.length} H1 heading(s) found.`,'SEO',2),
    result('canonical','Canonical URL',canonical?'pass':'warn',canonical?`Canonical: ${canonical}`:'No canonical link found.','SEO'),
    result('robots','Robots meta',robots?.toLowerCase().includes('noindex')?'warn':'pass',robots?`robots=${robots}`:'No page-level noindex directive found.','SEO'),
    result('viewport','Mobile viewport',viewport?'pass':'fail',viewport?'Viewport meta tag found.':'Missing viewport meta tag.','Mobile',2),
    result('lang','Document language',lang?'pass':'warn',lang?`Language: ${lang}`:'Missing lang attribute on <html>.','Accessibility'),
    result('alt','Image alt text',missingAlt===0?'pass':missingAlt<=2?'warn':'fail',`${missingAlt} of ${imgs.length} image(s) missing alt attributes.`,'Accessibility',2),
    result('links','Accessible links',emptyLinks===0?'pass':'warn',`${emptyLinks} of ${links.length} link(s) have no obvious accessible name.`,'Accessibility'),
    result('og','Open Graph title',ogTitle?'pass':'warn',ogTitle?'og:title found.':'No og:title found.','Social'),
    result('size','HTML size',html.length<500000?'pass':html.length<1000000?'warn':'fail',`${Math.round(html.length/1024)} KB HTML document.`,'Performance'),
    result('response','Response time',elapsed<1500?'pass':elapsed<3500?'warn':'fail',`${elapsed} ms to fetch from the audit server.`,'Performance',2)
  ];
  const earned = checks.reduce((s,c)=>s+(c.status==='pass'?c.points:c.status==='warn'?c.points*.5:0),0); const total = checks.reduce((s,c)=>s+c.points,0);
  return { url: response.url, auditedAt: new Date().toISOString(), score: Math.round(earned/total*100), stats:{images:imgs.length,links:links.length,h1:h1s.length,htmlKB:Math.round(html.length/1024),responseMs:elapsed}, checks };
}

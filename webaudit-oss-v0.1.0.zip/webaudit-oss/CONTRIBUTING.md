# Contributing

Thanks for helping improve WebAudit OSS.

1. Open an issue for substantial changes.
2. Fork the repository and create a focused branch.
3. Keep audit messages understandable to non-experts.
4. Do not add checks that intentionally bypass access controls or target private networks.
5. Submit a pull request describing what changed and how you tested it.
